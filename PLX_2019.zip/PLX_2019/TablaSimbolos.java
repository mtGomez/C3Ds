import java.util.HashMap;
public class TablaSimbolos{
	public static HashMap<String,Tipo> tablaSimbolos = new HashMap<String,Tipo>();

	public static void put(String key,Tipo value){
		tablaSimbolos.put(key,value);
	}

	public static String get(String key){
		return tablaSimbolos.get(key).tipo;
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}

	public static void init(String tipo,String keys){
		String[] k = keys.split("%");
		for (int i = 0; i < k.length; i++) {
			Tipo aux = tablaSimbolos.get(k[i]);
			aux.tipo = tipo;
		}
	}

	public static void arrInit(String id,int n,String valores){
		String[] aux = valores.split("%");
		if(aux.length > n) Core.gc(Core.ERR,"","","");
		else{
			for (int i = 0; i < aux.length; i++) {
				Core.gc(Core.ASIG,id+"["+i+"]",aux[i],"");
			}
		}
	}

	public static void change(String key,String tipo){
		Tipo aux = tablaSimbolos.get(key);
		aux.tipo = tipo;
	}

	public static String getValue(String key){
		return tablaSimbolos.get(key).valor;
	}

	public static int getLong(String key){
		return tablaSimbolos.get(key).longitud;
	}

	public static void printStr(String id){
		String str = getValue(id);
		char[] aux = new char[100];
		for (int i = 0; i < str.length(); i++) {
			aux[i] = str.charAt(i);
			int n = (int)aux[i];
			Core.gc(Core.WRITEC,String.valueOf(n),"","");
		}
		Core.gc(Core.WRITEC,"10","","");
	}

	public static void changeValue(String id1,String id2){
		if(contains(id2)){
			Tipo aux = tablaSimbolos.get(id1);
			String str2 = getValue(id2);
			aux.valor = str2;
		}else{ //+=
			Tipo aux = tablaSimbolos.get(id1);
			String str2 = id2;
			aux.valor = str2;
		}
	}

	public static String concat(String st1,String st2){
		String v1 = getValue(st1);
		String v2 = getValue(st2);
		if(get(st1).equals("char")){
			int aux = Integer.parseInt(getValue(st1));
			char a = (char)aux;
			v1 = Character.toString(a);
		}
		if(get(st2).equals("char")){
			int aux = Integer.parseInt(getValue(st2));
			char a = (char)aux;
			v2 = Character.toString(a);
		}
		return v1+v2;
	}

}
