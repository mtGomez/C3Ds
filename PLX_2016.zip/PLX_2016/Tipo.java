public class Tipo{
	private static int tipoBase;
	private int numElem;
	static final int ARRAY = 1;
	static final int INT = 2; 
	static final int VAR = 3;

	public Tipo(int tipo, int numElem,int tipoBase){
		this.numElem = numElem;
		this.tipoBase = tipoBase;
	}

	public Tipo(int tipo, int tipoBase){
		this.numElem = 1;
		this.tipoBase = tipoBase;
	}

	public static int getTipo(){
		return tipoBase;
	}
}
