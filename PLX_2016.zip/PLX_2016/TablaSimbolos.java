import java.util.HashMap;
public class TablaSimbolos{
	public static HashMap<String,String> tablaSimbolos = new HashMap();

	public static void put(String key,String value){
		tablaSimbolos.put(key,value);
	}

	public static String get(String key){
		return "";
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}

}
