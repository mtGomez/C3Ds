public class Core{
	public static int temp = -1;
	public static int etiq = -1;
	public static final int IADD = 1;
	public static final int ISUB = 2;
	public static final int IMUL = 3;
	public static final int IDIV = 4;
	public static final int ASIG = 5;
	public static final int MENOR = 6;
	public static final int IGUAL = 7;
	public static final int LABEL = 8;
	public static final int GOTO = 9;
	public static final int PRINT = 10;
	public static final int HALT = 11;
	public static final int ERR1 = 12;
	public static final int ERR2 = 13;
	public static final int INIT_METHOD = 14;
	public static final int END_METHOD = 15;
	public static final int SIPUSH = 16;
	public static final int ILOAD = 17;
	public static final int ISTORE = 18;
	public static final int DUP = 19;
	public static final int POP = 20;
	public static final int STATIC_METHOD = 21;
	public static final int RETURN = 22;
	public static final int NOP = 23;
	public static final int MAYOR = 24;			
	
	public static void gc(int op, String arg1, String arg2, String temp){
		switch(op) {
			case IADD:
				System.out.println("	iadd");
				break;
			case ISUB:
				System.out.println("	isub");
				break;
			case IMUL:
				System.out.println("	imul");
				break;
			case IDIV:
				System.out.println("	idiv");
				break;
			case ASIG:
				System.out.println("	"+arg1 + " = " + arg2 + ";");
				break;  
			case MENOR:
				System.out.println("	iflt "+temp);
				break;
			case MAYOR:
				System.out.println("	ifgt "+temp);
				break;   
			case IGUAL:
				System.out.println("	ifeq "+temp);
				break; 
			case LABEL:
				System.out.println(temp+":");
				break;  
			case GOTO:
				System.out.println("	goto "+temp);
				break;  
			case PRINT:
				System.out.println("	print "+arg1+";");
				break;  
			case HALT:
				System.out.println("halt;");
				break;
			case ERR1:
				System.out.println("error;");
				System.out.println("# Variable no declarada");
				break; 
			case ERR2:
				System.out.println("error;");
				System.out.println("# Variable ya declarada.");
				break;
			case INIT_METHOD:
				System.out.println(".method public static "+arg1+"(I)I");
				break;
			case STATIC_METHOD:
				System.out.println("	invokestatic JPL/"+arg1+"(I)I");
				break;
			case END_METHOD:
				System.out.println(".end method");
				System.out.println();
				break;   
			case SIPUSH:
				System.out.println("	sipush "+arg1);
				break; 
			case ILOAD:
				System.out.println("	iload "+arg1);
				break;
			case ISTORE:
				System.out.println("	istore "+arg1);
				break;
			case DUP:
				System.out.println("	dup");
				break; 
			case POP:
				System.out.println("	pop");
				break; 
			case RETURN:
				System.out.println("	ireturn");
				break;  
			case NOP:
				System.out.println("	nop");
				break;         
			default:
				System.err.println("Syntax error...");
		}
	}

	public static String nuevaTemp(){
		temp++;
		return "t"+temp;
	}

	public static String nuevaEtiq(){
		etiq++;
		return "L"+etiq;
	}

}
