import java.util.LinkedHashMap;
import java.awt.List;
import java.util.ArrayList;
public class TablaSimbolos{
	public static LinkedHashMap<String,String> tablaSimbolos = new LinkedHashMap<String,String>();

	public static void put(String key,String value){
		tablaSimbolos.put(key,value);
	}

	public static String getPos(String key){
		int i = 0;
		for (String entrada : tablaSimbolos.keySet()) {
		    //System.out.println(entrada);
		    if(entrada.equalsIgnoreCase(key)) return Integer.toString(i);
		    i++;
		}
		return "-1";
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}

}
