import java.util.ArrayList;
public class ListaSwitch{
	private static ArrayList<String> listaSwitch = new ArrayList<String>();
	private static ArrayList<String> listaExit = new ArrayList<String>();
	
	public static void add(String id) {
		listaSwitch.add(id);
	}
	
	public static void remove() {
		listaSwitch.remove(listaSwitch.size()-1);
	}
	
	public static String get() {
		return listaSwitch.get(listaSwitch.size()-1);
	}

	public static void addExit(String id) {
		listaExit.add(id);
	}
	
	public static void removeExit() {
		listaExit.remove(listaExit.size()-1);
	}
	
	public static String getExit() {
		return listaExit.get(listaExit.size()-1);
	}


}
