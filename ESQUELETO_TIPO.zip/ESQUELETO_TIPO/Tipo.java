public class Tipo{
	public String tipo;
	public String valor;
	public int longitud = 0;
	public int esArray = 0;

	public Tipo(String tipo,String valor){
		this.tipo = tipo;
		this.valor = valor;
	}

	public Tipo(String tipo,int longitud, int esArray){
		this.tipo = tipo;
		this.longitud = longitud;
		this.esArray = esArray;
	}

}
