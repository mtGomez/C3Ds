import java.util.HashMap;
public class TablaSimbolos{
	public static HashMap<String,Tipo> tablaSimbolos = new HashMap<String,Tipo>();

	public static void put(String key,Tipo value){
		tablaSimbolos.put(key,value);
	}

	public static String get(String key){
		return "";
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}

}
