public class DosEtiquetas{
	private String v;
	private String f;

	public DosEtiquetas(){
		v = Core.nuevaEtiq();
		f = Core.nuevaEtiq();
	}

	public DosEtiquetas(String v,String f){
		this.v = v;
		this.f = f;
	}

	public String v(){
		return v;
	}

	public String f(){
		return f;
	}
}
