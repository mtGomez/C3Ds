import java.io.PrintStream;
public class Core{
	protected static PrintStream out = System.out;
	public static int temp = -1;
	public static int etiq = -1;
	public static final int MAS = 1;
	public static final int MENOS = 2;
	public static final int POR = 3;
	public static final int DIV = 4;
	public static final int ASIG = 5;
	public static final int MENOR = 6;
	public static final int IGUAL = 7;
	public static final int LABEL = 8;
	public static final int GOTO = 9;
	public static final int PRINT = 10;
	public static final int HALT = 11;
	public static final int ERR1 = 12;
	public static final int ERR2 = 13;		
	
	public static void gc(int op, String arg1, String arg2, String temp){
		switch(op) {
			case MAS:
				out.println("	"+temp + " = " + arg1 + " + " + arg2 + ";");
				break;
			case MENOS:
				out.println("	"+temp + " = " + arg1 + " - " + arg2 + ";");
				break;
			case POR:
				out.println("	"+temp + " = " + arg1 + " * " + arg2 + ";");
				break;
			case DIV:
				out.println("	"+temp + " = " + arg1 + " / " + arg2 + ";");
				break;
			case ASIG:
				out.println("	"+arg1 + " = " + arg2 + ";");
				break;  
			case MENOR:
				out.println("	if ("+arg1+" < "+arg2+") goto "+temp+";");
				break;  
			case IGUAL:
				out.println("	if ("+arg1+" == "+arg2+") goto "+temp+";");
				break; 
			case LABEL:
				out.println(temp+":");
				break;  
			case GOTO:
				out.println("	goto "+temp+";");
				break;  
			case PRINT:
				out.println("	print "+arg1+";");
				break;  
			case HALT:
				out.println("halt;");
				break;
			case ERR1:
				out.println("error;");
				out.println("# Variable no declarada");
				break; 
			case ERR2:
				out.println("error;");
				out.println("# Variable ya declarada.");
				break;   
			default:
				out.println("Syntax error...");
		}
	}

	public static String nuevaTemp(){
		temp++;
		return "t"+temp;
	}

	public static String nuevaEtiq(){
		etiq++;
		return "L"+etiq;
	}

}
