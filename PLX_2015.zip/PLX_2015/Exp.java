public class Exp{
	private static String nombre;
	private static String tipo;

	public Exp(String nombre,String tipo){
		this.nombre = nombre;
		this.tipo = tipo;
	}

	public static String nombre(){
		return nombre;
	}

	public static String tipo(){
		return tipo;
	}
}
