import java.util.HashMap;
public class TablaSimbolos{
	public static HashMap<String,String> tablaSimbolos = new HashMap<String,String>();

	public static void put(String key,String value){
		tablaSimbolos.put(key,value);
	}

	public static void declare(String lista,String tipo){
		String[] array = lista.split("-");
		for(int i=0; i<array.length; i++){
			//System.out.println(array[i]+tipo);
			tablaSimbolos.put(array[i],tipo);
		}
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}

	public static String get(String key){
		return tablaSimbolos.get(key);
	}

}
