import java.util.HashMap;
import java.util.Map.Entry;
public class TablaSimbolos{
	public static HashMap<String,Object> tablaSimbolos = new HashMap<String,Object>();

	public static void put(String key,Object value){
		tablaSimbolos.put(key,value);
	}

	public static Object get(String key){
		return tablaSimbolos.get(key);
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}
	
	public static void bump(){
		for (Entry<String, Object> entry : tablaSimbolos.entrySet())  
            System.out.println("Key = " + entry.getKey() + 
                             ", Value = " + entry.getValue());
	}

}
