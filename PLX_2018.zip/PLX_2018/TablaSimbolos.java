import java.util.HashMap;
public class TablaSimbolos{
	public static HashMap<String,Tipo> tablaSimbolos = new HashMap<String,Tipo>();

	public static void put(String key,Tipo value){
		tablaSimbolos.put(key,value);
	}

	public static String get(String key){
		return tablaSimbolos.get(key).tipo;
	}

	public static boolean contains(String key){
		if(tablaSimbolos.isEmpty()) return false;
		return tablaSimbolos.containsKey(key);
	}

	public static void init(String tipo,String keys){
		String[] k = keys.split("%");
		for (int i = 0; i < k.length; i++) {
			Tipo aux = tablaSimbolos.get(k[i]);
			aux.tipo = tipo;
		}
	}

	public static void arrInit(String id,int n,String valores){
		String[] aux = valores.split("%");
		if(aux.length > n) Core.gc(Core.ERR,"","","");
		else{
			for (int i = 0; i < aux.length; i++) {
				Core.gc(Core.ASIG,id+"["+i+"]",aux[i],"");
			}
		}
	}

	public static void change(String key,String tipo){
		Tipo aux = tablaSimbolos.get(key);
		aux.tipo = tipo;
	}

	public static String getValue(String key){
		return tablaSimbolos.get(key).valor;
	}

	public static int getLong(String key){
		return tablaSimbolos.get(key).longitud;
	}

}
