import java.io.FileReader;
import java.io.IOException;

public class wc {
    protected static int nLineas = 0;
	protected static int nPalabras = 0;
	protected static int nCaracteres = 0;
    
	public static void contadorLineas() {
    	nLineas++;
    }
	
    public static void contadorPalabras() {
    	nPalabras++;
    }
    
	public static void contadorCaracteres(int x) {
    	nCaracteres += x;
    }

    public static void main(String arg[]) {
    
        if (arg.length>0) {
            try {
                Yylex lex = new Yylex(new FileReader(arg[0]));
                Yytoken yytoken = null;
		while (  (yytoken = lex.yylex()) != null  ) {
                    //System.out.println(yytoken);
                    if (yytoken.getToken() == Yytoken.PALABRA)  {
					   wc.contadorPalabras();
					   wc.contadorCaracteres(yytoken.getValor());
                    } else if (yytoken.getToken() == Yytoken.EOLN) {
                       wc.contadorLineas();
                    } 
                }
				System.out.println(nLineas+"      "+nPalabras+"      "+nCaracteres+" "+arg[0]);
	    } catch (IOException e) {
	    }
        }
    }

}
