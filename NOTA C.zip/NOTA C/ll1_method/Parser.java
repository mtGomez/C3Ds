import java.io.FileReader;
import java.io.IOException;
import java.io.FileReader;

class Parser {

private static int token;
private static Yylex lex;
private static int yylex() {
	try {
		token = lex.yylex();
	} catch (IOException e) {
		System.out.println("IOException");
		System.exit(0);
	}
	return token;
}

public static void main(String[] arg) {
    if (arg.length>0) {
        try {
            lex = new Yylex(new FileReader(arg[0]));
			Parser.axioma();
        } catch (IOException e) {
        } 
    }
}

public static void axioma(){
	//R0
	Yytoken.regla(0);
	yylex();
	listaSent();		
}

public static void listaSent(){
	if(token == Yytoken.WHILE || token == Yytoken.DO || token == Yytoken.IDENT || token == Yytoken.ALL){ //R1
		Yytoken.regla(1);
		sent();
		listaSent();
	}else if(yylex() == Yytoken.CLL){ //R2
		Yytoken.regla(2);
	}else if(yylex() == Yytoken.EOF){ //R2
		Yytoken.regla(2);
		System.exit(0);
	}else{
		Yytoken.error(token);
	}
}

public static void sent(){
	if(token == Yytoken.WHILE){ //R3
		Yytoken.regla(3);
		yylex();
		yylex();
		cond();
		yylex();
		sent();
	}else if(token == Yytoken.DO){ //R4
		Yytoken.regla(4);
		yylex();
		sent();
		yylex();
		yylex();
		cond();
		yylex();
		yylex();
	}else if(token == Yytoken.IDENT){ //R5
		Yytoken.regla(5);
		yylex();
		yylex();
		var();
		yylex();
	}else if(token == Yytoken.ALL){ //R6
		Yytoken.regla(6);
		yylex();
		listaSent();
		yylex();
	}else{
		Yytoken.error(token);
	}
}

public static void cond(){
	if(token == Yytoken.IDENT || token == Yytoken.NUMERO){ //R7
		Yytoken.regla(7);
		var();
		yylex();
		var();
	}else{
		Yytoken.error(token);
	}		
}

public static void var(){
	if(token == Yytoken.IDENT){ //R8
		Yytoken.regla(8);
		yylex();
	}else if(token == Yytoken.NUMERO){ //R9
		Yytoken.regla(9);
		yylex();
	}else{
		Yytoken.error(token);
	}		
}

}