import java.io.FileReader;
import java.io.IOException;

public class cpv {
    protected static int sumaA = 0;
	protected static int sumaB = 0;
	protected static int sumaC = 0;
	protected static int sumaD = 0;
    
    public static void tipoA() {
    	sumaA++;
    }
    
    public static void tipoB() {
    	sumaB++;
    }
	
	public static void tipoC() {
    	sumaC++;
    }
	
	public static void tipoD() {
    	sumaD++;
    }
    
    
    public static void main(String arg[]) {
    
        if (arg.length>0) {
            try {
                Yylex lex = new Yylex(new FileReader(arg[0]));
                Yytoken yytoken = null;
		while (  (yytoken = lex.yylex()) != null  ) {
                    //System.out.println(yytoken);
                    if (yytoken.getToken() == Yytoken.TIPO_A) cpv.tipoA(); 
                    if (yytoken.getToken() == Yytoken.TIPO_B) cpv.tipoB(); 
					if (yytoken.getToken() == Yytoken.TIPO_C) cpv.tipoC(); 
					if (yytoken.getToken() == Yytoken.TIPO_D) cpv.tipoD();      
                }
				System.out.println("A "+sumaA);
				System.out.println("B "+sumaB);
				System.out.println("C "+sumaC);
				System.out.println("D "+sumaD);
	    } catch (IOException e) {
	    }
        }
    }

}
