import java.util.ArrayList;
import java.util.HashMap;

public class TablaSimbolos {
	private static ArrayList<HashMap<String, String>> tablaSimbolos = new ArrayList<HashMap<String,String>>();
	private static int contador = -1;
	
	public static boolean isDeclared(String key){
		if(tablaSimbolos.isEmpty()) return false; //OutOfBounds
		return tablaSimbolos.get(contador).containsKey(key);
	}

	public static boolean contains(String key) {
		boolean res = false;
		for (HashMap<String, String> hashMap : tablaSimbolos) {
			if(hashMap.containsKey(key)) return true;
		}
		return res;
	}
	
	public static void nuevoBloque() {
		HashMap<String, String> bloque = new HashMap<String, String>();
		tablaSimbolos.add(bloque);
		contador++;
	}
	
	public static void borrarBloque() {
		tablaSimbolos.remove(contador);
		contador--;
	}
	
	public static void put(String key,String value) {
 		if(tablaSimbolos.isEmpty()) TablaSimbolos.nuevoBloque(); 
		tablaSimbolos.get(contador).put(key, value);
	}
	
	public static String get(String key) {
		for (int i = contador; i >= 0 ; i--) {
			if(tablaSimbolos.get(i).containsKey(key)) {
				for (String name : tablaSimbolos.get(i).keySet()) {
					if(key.equalsIgnoreCase(name)) return name+"_"+i;
				}
			}
		}
		return "";
	}
	
}
